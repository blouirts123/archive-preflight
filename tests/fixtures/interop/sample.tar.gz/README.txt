Small synthetic archive interoperability fixture.
